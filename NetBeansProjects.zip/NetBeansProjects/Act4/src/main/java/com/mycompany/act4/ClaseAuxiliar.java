/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.act4;

public class ClaseAuxiliar {
    private String producto;
    private String categoria;
    private String marca;
    private int cantidad;
    private double precioUnitario;

    public ClaseAuxiliar(String producto, String categoria, String marca, int cantidad, double precioUnitario) {
        this.producto = producto;
        this.categoria = categoria;
        this.marca = marca;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    // Getters
    public String getProducto() { return producto; }
    public String getCategoria() { return categoria; }
    public String getMarca() { return marca; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }

    // Setters
    public void setProducto(String producto) { this.producto = producto; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setMarca(String marca) { this.marca = marca; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setPrecioUnitario(double precioUnitario) { this.precioUnitario = precioUnitario; }
}