/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pruebas;

import java.util.logging.Logger;

/**
 *
 * @author PC104
 */
public class Pruebas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
    }
    private static final Logger LOG = Logger.getLogger(Pruebas.class.getName());
    
    

    public Pruebas() {
    }
}
