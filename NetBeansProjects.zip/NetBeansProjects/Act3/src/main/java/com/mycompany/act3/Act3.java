/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.act3;

/**
 *
 * @author PC104
 */
public class Act3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
